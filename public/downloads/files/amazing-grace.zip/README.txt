Amazing Grace
John Newton, 1779. Public domain.

Includes three verses and a saved arrangement.
Unzip, then open Libraries > Songs > Import song and select amazing-grace.json.
