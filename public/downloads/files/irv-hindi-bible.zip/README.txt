Indian Revised Version · Hindi

© 2017, 2018, 2019 Bridge Connectivity Solutions
CC BY-SA 4.0 · https://creativecommons.org/licenses/by-sa/4.0/
Source: https://ebible.org/bible/details.php?id=hin2017

66 books; 31,104 verses. Verse text is unchanged from Selah's bundled seed.
Packaged as Selah JSON; internal book identifiers use USFM codes. Original source notice included.
0 blank source records omitted because Selah imports require nonempty verse text. Original verse numbering is retained.

This translation is already bundled with Selah. You do not need to import it again.
To install a missing translation: unzip, open Libraries > Bible > Import translation,
and choose hin2017.json. Selah rejects an ID that is already installed.

Retain the source notice and attribution when sharing.
