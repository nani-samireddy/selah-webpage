Sunday service preset

An example saved program with six items: welcome, Amazing Grace, Psalm 23,
message title, prayer, and community announcements. All text remains editable.
This is an illustrative service, not a real church schedule.

Unzip, open Programs > Import, then choose sunday-worship.churchprogram.
Update the title and date before using it. Imported programs receive independent identities.

Presentation layouts: CC0. Amazing Grace: John Newton, 1779, public domain.
Scripture: World English Bible, public domain.
