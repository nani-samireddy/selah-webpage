Selah original demo song collection

Five original demonstration songs in English, Telugu, Hindi, and paired English/Telugu.
These are sample songs for trying Selah, not a licensed worship-song catalog.
Credits are retained in each file; original demo lyrics are CC0.

Unzip, then open Libraries > Songs > Import song and choose each JSON file separately.
SongSelect, OpenLyrics, and other third-party formats are not included.
