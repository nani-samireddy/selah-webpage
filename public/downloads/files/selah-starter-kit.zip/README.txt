Selah starter kit

Includes original demonstration songs, Amazing Grace, three reusable templates,
and one example Sunday service. Bible packages are downloaded separately.

Import each resource through its matching Selah library:
Songs: Libraries > Songs > Import song (one JSON at a time).
Templates: Libraries > Templates > Import (.churchtemplate).
Service preset: Programs > Import (.churchprogram).

Fonts: Inter and Noto Sans Telugu are bundled with Selah. Georgia uses the
system-installed font; choose another serif if unavailable on your computer.

Original demo lyrics and new layouts: CC0. Amazing Grace and WEB text: public domain.
Keep credits when sharing and check presentation previews before taking content live.
