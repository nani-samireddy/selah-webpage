World English Bible

Public domain · eBible.org
Public domain
Source: https://ebible.org/bible/details.php?id=engwebp

66 books; 31,098 verses. Verse text is unchanged from Selah's bundled seed.
Packaged as Selah JSON; internal book identifiers use USFM codes. Original source notice included.
5 blank source records omitted because Selah imports require nonempty verse text. Original verse numbering is retained.

This translation is already bundled with Selah. You do not need to import it again.
To install a missing translation: unzip, open Libraries > Bible > Import translation,
and choose engwebp.json. Selah rejects an ID that is already installed.

Retain the source notice and attribution when sharing.
